# XAVIABOT 

[![Original](https://img.shields.io/badge/Original-XaviaTeam-blue?style=flat-square)](https://github.com/XaviaTeam/XaviaBot)

> Modified version. Files may contain bugs due to changes.
> **Do not remove credits.** Risk of global ban if modified. Shared on official XaviaBot server on Discord.

**Fixed by Rapido**

### How to use?
1. configure your name of your bot and your Facebook UID on config.main.json file
2. Put your bot's appstate on appstate.json file (Not recommend to use personal account)
## Setup
1. Clone repo
2. `npm install`
3. Configure env
4. `npm start`

## Disclaimer
Modified version. Use at your own risk.

## Credits
- Original: [XaviaTeam](https://github.com/XaviaTeam)
- Fixes: Rapido


